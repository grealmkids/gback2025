const {
  User,
  ClientAlbum,
  Album,
  BillingAddress,
  Category,
  Video,
  Book,
  AfricanStory,
  HomepageService
} = require("../models");

// Update the attributes to include 'downloadUrl' (renamed to 'downloadLink' in the response)
exports.viewPurchasedAlbums = async (req, res) => {
  const { clientId } = req.query;

  if (!clientId) {
    return res
      .status(400)
      .json({ message: "clientId is required in the query parameters." });
  }

  try {
    const purchasedAlbums = await ClientAlbum.findAll({
      where: { userId: clientId },
      include: [
        {
          model: Album,
          // attributes: ["title", ["downloadUrl", "downloadLink"]], // Fetches all attributes now for details modal
        },
      ],
    });

    res.json(purchasedAlbums);
  } catch (error) {
    console.error("Error in viewPurchasedAlbums:", error);
    res.status(500).json({ message: "Server error", error });
  }
};

// Modify the API to exclude the `downloadUrl` field and support optional status filtering when returning all albums
exports.getAllAlbums = async (req, res) => {
  const { status } = req.query;
  try {
    const where = {};
    if (status) {
      where.status = status;
    }

    const albums = await Album.findAll({
      where,
      attributes: { exclude: ["downloadUrl"] },
    });
    console.log(`=== FETCHED ALBUMS(${albums.length}) === `);
    if (albums.length > 0) {
      console.log(JSON.stringify(albums, null, 2));
    } else {
      console.log('No albums found in database.');
    }
    res.status(200).json(albums);
  } catch (error) {
    console.error("Error fetching albums:", error);
    res.status(500).json({ message: "Failed to fetch albums", error });
  }
};

// Save or update billing address for a user
exports.saveBillingAddress = async (req, res) => {
  console.log("=== Billing Address Save Request ===");
  console.log("Request body:", JSON.stringify(req.body, null, 2));

  try {
    const {
      email,
      branch,
      email_address,
      phone_number,
      country_code,
      first_name,
      middle_name,
      last_name,
      line_1,
      line_2,
      city,
      state,
      postal_code,
      zip_code,
    } = req.body;

    // Input validation
    if (
      !email ||
      !branch ||
      !email_address ||
      !phone_number ||
      !first_name ||
      !last_name ||
      !line_1
    ) {
      return res.status(400).json({
        message:
          "Required fields: email, branch, email_address, phone_number, first_name, last_name, line_1",
      });
    }

    console.log(`Looking for user with email: ${email} `);

    // Find user by email
    let user = await User.findOne({ where: { email } });
    console.log(
      `User found: `,
      user ? `ID: ${user.id}, Email: ${user.email} ` : "No user found"
    );

    if (!user) {
      console.log(`Creating new user with email: ${email} `);
      // Auto-create user if they don't exist
      user = await User.create({
        email,
        password: "", // Password will be set via OTP
        role: "client",
        phone: phone_number || null,
        firstname: first_name || null,
        lastname: last_name || null,
      });
      console.log(`User created successfully: ID ${user.id} `);
    }

    // Check if billing address already exists for this user
    const existingBillingAddress = await BillingAddress.findOne({
      where: { userId: user.id },
    });

    const billingData = {
      userId: user.id,
      branch,
      email_address,
      phone_number,
      country_code: country_code || "KE",
      first_name,
      middle_name: middle_name || null,
      last_name,
      line_1,
      line_2: line_2 || null,
      city: city || null,
      state: state || null,
      postal_code: postal_code || null,
      zip_code: zip_code || null,
    };

    let billingAddress;
    if (existingBillingAddress) {
      // Update existing billing address
      await BillingAddress.update(billingData, {
        where: { userId: user.id },
      });
      billingAddress = await BillingAddress.findOne({
        where: { userId: user.id },
      });
      res.status(200).json({
        message: "Billing address updated successfully",
        billingAddress,
      });
    } else {
      // Create new billing address
      billingAddress = await BillingAddress.create(billingData);
      res.status(201).json({
        message: "Billing address saved successfully",
        billingAddress,
      });
    }
  } catch (error) {
    console.error("=== ERROR SAVING BILLING ADDRESS ===");
    console.error("Error name:", error.name);
    console.error("Error message:", error.message);
    if (error.original) {
      console.error("Original error:", error.original);
    }
    console.error("=== END ERROR ===");

    // Handle Unique Constraint Error (e.g. Phone number already exists)
    if (error.name === 'SequelizeUniqueConstraintError') {
      let field = error.errors[0]?.path;
      if (field === 'phone' || field === 'phone_number') field = 'Phone number';
      if (field === 'email' || field === 'email_address') field = 'Email address';

      return res.status(409).json({
        message: `${field} already exists.Please use a different one or contact support.`,
        errorType: error.name
      });
    }

    res.status(500).json({
      message: "Failed to save billing address",
      error: error.message,
      errorType: error.name,
    });
  }
};

// Get billing address for a user
exports.getBillingAddress = async (req, res) => {
  try {
    const { email } = req.query;

    if (!email) {
      return res.status(400).json({
        message: "Email is required in query parameters",
      });
    }

    // Find user by email
    const user = await User.findOne({ where: { email } });
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // Find billing address for the user
    const billingAddress = await BillingAddress.findOne({
      where: { userId: user.id },
      include: [
        {
          model: User,
          attributes: ["email", "role"],
        },
      ],
    });

    if (!billingAddress) {
      return res
        .status(404)
        .json({ message: "Billing address not found for this user" });
    }

    res.status(200).json(billingAddress);
  } catch (error) {
    console.error("Error fetching billing address:", error);
    res.status(500).json({
      message: "Failed to fetch billing address",
      error: error.message,
    });
  }
};

// Create user if not exists (for billing address)
exports.createUserIfNotExists = async (req, res) => {
  try {
    const { email, phone, firstName, lastName } = req.body;

    if (!email) {
      return res.status(400).json({ message: "Email is required" });
    }

    // Check if user already exists
    let user = await User.findOne({ where: { email } });

    if (user) {
      return res.status(200).json({
        message: "User already exists",
        user: { id: user.id, email: user.email, role: user.role },
      });
    }

    // Create new user
    user = await User.create({
      email,
      password: "", // Password will be set via OTP
      role: "client",
      phone: phone || null,
      firstname: firstName || null,
      lastname: lastName || null,
    });

    res.status(201).json({
      message: "User created successfully",
      user: { id: user.id, email: user.email, role: user.role },
    });
  } catch (error) {
    console.error("Error creating user:", error);
    res.status(500).json({
      message: "Failed to create user",
      error: error.message,
    });
  }
};

// Download file proxy to force download
exports.downloadFile = async (req, res) => {
  const { url, filename } = req.query;

  if (!url || !filename) {
    return res.status(400).json({ message: "URL and filename are required." });
  }

  try {
    const axios = require("axios");
    const response = await axios({
      method: "GET",
      url: url,
      responseType: "stream",
    });

    res.setHeader("Content-Disposition", `attachment; filename = "${filename}"`);
    res.setHeader("Content-Type", response.headers["content-type"]);

    response.data.pipe(res);
  } catch (error) {
    console.error("Error downloading file:", error);
    res.status(500).json({ message: "Failed to download file.", error: error.message });
  }
};

exports.getCategories = async (req, res) => {
  try {
    const categories = await Category.findAll({ order: [['displayOrder', 'ASC']] });
    res.status(200).json(categories);
  } catch (error) {
    console.error("Error fetching categories:", error);
    res.status(500).json({ message: "Failed to fetch categories" });
  }
};

exports.getProductsByCategory = async (req, res) => {
  const { categoryId } = req.params;
  try {
    const category = await Category.findByPk(categoryId);
    if (!category) return res.status(404).json({ message: "Category not found" });

    let products = [];
    // 'PDF' -> Books

    if (category.name.includes("Albums")) {
      products = await Album.findAll({ where: { categoryId } });
    } else if (category.name.includes("African")) { // African Stories
      products = await AfricanStory.findAll({ where: { categoryId } });
    } else if (category.type === 'VIDEO') {
      products = await Video.findAll({ where: { categoryId } });
    } else if (category.type === 'PDF') {
      products = await Book.findAll({ where: { categoryId } });
    } else {
      // Fallback: try to find in AfricanStory if name match fails but type might be unique?
      // For now stick to name matching for specific custom types
    }

    res.status(200).json({ category, products });
  } catch (error) {
    console.error("Error fetching products:", error);
    res.status(500).json({ message: "Failed to fetch products" });
  }
};

exports.getProductDetails = async (req, res) => {
  const { categoryId, productId } = req.params;
  try {
    const category = await Category.findByPk(categoryId);
    if (!category) return res.status(404).json({ message: "Category not found" });

    let product = null;

    if (category.name.includes("Albums")) {
      product = await Album.findByPk(productId);
    } else if (category.name.includes("African")) {
      product = await AfricanStory.findByPk(productId);
    } else if (category.type === 'VIDEO') {
      product = await Video.findByPk(productId);
    } else if (category.type === 'PDF') {
      product = await Book.findByPk(productId);
    }

    if (!product) {
      return res.status(404).json({ message: "Product not found" });
    }

    res.status(200).json({ category, product });
  } catch (error) {
    console.error("Error fetching product details:", error);
    res.status(500).json({ message: "Failed to fetch product details" });
  }
};
exports.getHomepageServices = async (req, res) => {
  try {
    const services = await HomepageService.findAll({ order: [['displayOrder', 'ASC']] });
    res.status(200).json(services);
  } catch (error) {
    console.error("Error fetching homepage services:", error);
    res.status(500).json({ message: "Failed to fetch homepage services" });
  }
};

exports.proxyPdf = async (req, res) => {
  const { url } = req.query;
  if (!url) {
    return res.status(400).send('URL is required');
  }

  const https = require('https');
  const http = require('http');

  const client = url.startsWith('https') ? https : http;

  client.get(url, (proxyRes) => {
    if (proxyRes.statusCode !== 200) {
      return res.status(proxyRes.statusCode).send('Failed to fetch remote file');
    }

    // Forward relevant headers
    res.setHeader('Content-Type', proxyRes.headers['content-type'] || 'application/pdf');
    res.setHeader('Access-Control-Allow-Origin', '*'); // Allow frontend to read this

    proxyRes.pipe(res);
  }).on('error', (err) => {
    console.error('Proxy Error:', err);
    res.status(500).send('Error fetching file');
  });
};
